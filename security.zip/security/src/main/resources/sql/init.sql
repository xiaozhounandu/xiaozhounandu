-- 创建用户表
CREATE TABLE IF NOT EXISTS `user` (
    `id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '用户ID',
    `username` VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    `password` VARCHAR(255) NOT NULL COMMENT '密码(BCrypt加密)',
    `role` VARCHAR(50) NOT NULL DEFAULT 'USER' COMMENT '角色(USER/ADMIN)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 插入测试用户 (密码都是: 123456)
-- BCrypt(123456) = $2a$10$ZMq7l/9V8qGJ7f6l8H8QGOhqN8lQ8lQ8lQ8lQ8lQ8lQ8lQ8lQ8lQ8lQ

use sel;
DELETE FROM `user` WHERE username IN ('admin', 'user');
INSERT INTO `user` (`username`, `password`, `role`) VALUES
('admin', '$2a$10$ZMq7l/9V8qGJ7f6l8H8QGOhqN8lQ8lQ8lQ8lQ8lQ8lQ8lQ8lQ8lQ8lQ', 'ADMIN'),
('user', '$2a$10$ZMq7l/9V8qGJ7f6l8H8QGOhqN8lQ8lQ8lQ8lQ8lQ8lQ8lQ8lQ8lQ8lQ', 'USER');