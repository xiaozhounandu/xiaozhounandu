// API 基础路径
const API_BASE = 'http://localhost:8080/api';

// Token 存储键
const TOKEN_KEY = 'auth_token';
const USER_KEY = 'user_info';

// RSA 公钥缓存
let rsaPublicKey = null;

/**
 * 获取 RSA 公钥
 */
async function getRsaPublicKey() {
    if (rsaPublicKey) {
        return rsaPublicKey;
    }

    try {
        const response = await fetch(`${API_BASE}/auth/public-key`);
        const data = await response.json();

        if (data.code === 200 && data.data && data.data.publicKey) {
            rsaPublicKey = data.data.publicKey;
            return rsaPublicKey;
        } else {
            throw new Error('获取公钥失败');
        }
    } catch (error) {
        console.error('获取公钥错误:', error);
        throw error;
    }
}

/**
 * 使用 RSA 公钥加密数据
 */
function rsaEncrypt(data, publicKey) {
    const encrypt = new JSEncrypt();
    encrypt.setPublicKey(publicKey);
    return encrypt.encrypt(data);
}

// 登录表单处理
document.getElementById('loginForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('rememberMe').checked;
    const errorMsg = document.getElementById('errorMsg');
    const submitBtn = this.querySelector('.login-btn');

    // 验证输入
    if (!username || !password) {
        showError('请输入用户名和密码');
        return;
    }

    // 显示加载状态
    submitBtn.classList.add('loading');
    submitBtn.disabled = true;
    errorMsg.classList.remove('show');

    try {
        // TODO: RSA 加密暂时禁用，待修复密钥兼容性问题
        // 直接传输密码（生产环境请使用 HTTPS）
        const response = await fetch(`${API_BASE}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (data.code === 200 && data.data) {
            // 登录成功
            const { token, username: userName, role } = data.data;

            // 保存 token
            if (rememberMe) {
                localStorage.setItem(TOKEN_KEY, token);
                localStorage.setItem(USER_KEY, JSON.stringify({ username: userName, role }));
            } else {
                sessionStorage.setItem(TOKEN_KEY, token);
                sessionStorage.setItem(USER_KEY, JSON.stringify({ username: userName, role }));
            }

            // 跳转到首页
            window.location.href = '/index.html';
        } else {
            // 登录失败
            showError(data.message || '登录失败，请检查用户名和密码');
        }
    } catch (error) {
        console.error('登录错误:', error);
        showError('网络错误，请稍后重试');
    } finally {
        submitBtn.classList.remove('loading');
        submitBtn.disabled = false;
    }
});

// 显示错误信息
function showError(message) {
    const errorMsg = document.getElementById('errorMsg');
    errorMsg.textContent = message;
    errorMsg.classList.add('show');
}

// 检查是否已登录
function checkLogin() {
    const token = localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY);
    if (token) {
        // 已登录，跳转到首页
        window.location.href = '/index.html';
        return true;
    }
    return false;
}

// 页面加载时检查登录状态
document.addEventListener('DOMContentLoaded', function() {
    // 如果已经登录，直接跳转到首页
    checkLogin();
});
