// API 基础路径
const API_BASE = 'http://localhost:8080/api';

// Token 存储键
const TOKEN_KEY = 'auth_token';
const USER_KEY = 'user_info';

// 当前用户信息
let currentUser = null;

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    // 检查登录状态
    const token = getToken();
    if (!token) {
        // 未登录，跳转到登录页
        window.location.href = '/login.html';
        return;
    }

    // 获取用户信息
    currentUser = getUserInfo();
    if (!currentUser) {
        // Token 无效，跳转到登录页
        clearAuth();
        window.location.href = '/login.html';
        return;
    }

    // 初始化页面
    initPage();

    // 绑定退出按钮
    document.getElementById('logoutBtn').addEventListener('click', logout);

    // 绑定测试按钮
    document.querySelectorAll('.test-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const api = this.getAttribute('data-api');
            testApi(api);
        });
    });
});

// 初始化页面
function initPage() {
    // 显示用户信息
    document.getElementById('username').textContent = currentUser.username;
    document.getElementById('welcomeUsername').textContent = currentUser.username;

    const roleText = currentUser.role || 'UNKNOWN';
    document.getElementById('role').textContent = roleText;

    // 根据角色显示/隐藏按钮
    updateButtonsByRole();
}

// 根据角色更新按钮显示
function updateButtonsByRole() {
    const role = currentUser.role;

    // 管理员按钮
    const adminBtns = document.querySelectorAll('.admin-only');
    adminBtns.forEach(btn => {
        if (role !== 'ADMIN') {
            btn.classList.add('hidden');
        } else {
            btn.classList.remove('hidden');
        }
    });

    // 用户按钮
    const userBtns = document.querySelectorAll('.user-only');
    userBtns.forEach(btn => {
        if (role !== 'USER') {
            btn.classList.add('hidden');
        } else {
            btn.classList.remove('hidden');
        }
    });
}

// 测试 API
async function testApi(apiPath) {
    const responseSection = document.getElementById('responseSection');
    const responseContent = document.getElementById('responseContent');

    responseSection.style.display = 'block';
    responseContent.textContent = '加载中...';
    responseContent.classList.remove('success', 'error');

    try {
        const response = await fetch(`${API_BASE}${apiPath}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${getToken()}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            responseContent.textContent = JSON.stringify(data, null, 2);
            responseContent.classList.add('success');
        } else {
            responseContent.textContent = `请求失败 (${response.status})\n\n` + JSON.stringify(data, null, 2);
            responseContent.classList.add('error');

            // 如果是 401 或 403，可能是 token 过期，跳转到登录页
            if (response.status === 401 || response.status === 403) {
                setTimeout(() => {
                    alert('认证失败，请重新登录');
                    clearAuth();
                    window.location.href = '/login.html';
                }, 1000);
            }
        }
    } catch (error) {
        console.error('API 请求错误:', error);
        responseContent.textContent = `网络错误: ${error.message}`;
        responseContent.classList.add('error');
    }
}

// 获取 Token
function getToken() {
    return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY);
}

// 获取用户信息
function getUserInfo() {
    const info = localStorage.getItem(USER_KEY) || sessionStorage.getItem(USER_KEY);
    return info ? JSON.parse(info) : null;
}

// 退出登录
function logout() {
    if (confirm('确定要退出登录吗？')) {
        clearAuth();
        window.location.href = '/login.html';
    }
}

// 清除认证信息
function clearAuth() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(USER_KEY);
}
