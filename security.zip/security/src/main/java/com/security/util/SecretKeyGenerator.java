package com.security.util;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.crypto.KeyGenerator;

/**
 * 生成安全的 JWT Secret 密钥
 */
public class SecretKeyGenerator {

    public static void main(String[] args) throws Exception {
        // 生成 256 位 (32 字节) 的密钥，适合 HS256
        SecretKey key256 = KeyGenerator.getInstance("HmacSHA256").generateKey();
        String secret256 = Base64.getEncoder().encodeToString(key256.getEncoded());
        System.out.println("HS256 (256-bit):");
        System.out.println("jwt.secret=" + secret256);
        System.out.println();

        // 生成 512 位 (64 字节) 的密钥，适合 HS512（当前使用）
        SecretKey key512 = KeyGenerator.getInstance("HmacSHA512").generateKey();
        String secret512 = Base64.getEncoder().encodeToString(key512.getEncoded());
        System.out.println("HS512 (512-bit):");
        System.out.println("jwt.secret=" + secret512);
    }
}
