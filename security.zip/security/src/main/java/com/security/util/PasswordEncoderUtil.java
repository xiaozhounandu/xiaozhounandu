package com.security.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordEncoderUtil {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        // 生成密码 "password123" 的 BCrypt 哈希
        String rawPassword = "password123";
        String encodedPassword = encoder.encode(rawPassword);

        System.out.println("Raw password: " + rawPassword);
        System.out.println("Encoded password: " + encodedPassword);

        // 验证现有哈希
        String existingHash = "$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi";
        boolean matches = encoder.matches(rawPassword, existingHash);
        System.out.println("Existing hash matches 'password123': " + matches);

        // 测试简单密码
        String simplePassword = "123456";
        String encodedSimple = encoder.encode(simplePassword);
        System.out.println("Raw password: " + simplePassword);
        System.out.println("Encoded password: " + encodedSimple);
    }
}
