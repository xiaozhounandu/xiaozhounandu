package com.security.controller;

import com.security.common.Result;
import com.security.dto.LoginRequest;
import com.security.dto.LoginResponse;
import com.security.entity.user;
import com.security.filter.JwtAuthenticationFilter;
import com.security.service.userServcice;
import com.security.util.JwtUtil;
import com.security.util.RsaUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.security.KeyPair;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private userServcice userDetailsService;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private KeyPair rsaKeyPair;

    /**
     * 获取 RSA 公钥，用于前端加密密码
     */
    @GetMapping("/public-key")
    public Result<Map<String, String>> getPublicKey() {
        Map<String, String> result = new HashMap<>();
        result.put("publicKey", RsaUtil.getPublicKeyString(rsaKeyPair.getPublic()));
        return Result.success(result);
    }

    @PostMapping("/login")
    public Result<LoginResponse> login(@RequestBody LoginRequest loginRequest) {
        try {
            logger.info("登录请求: username={}", loginRequest.getUsername());

            // TODO: RSA 解密暂时禁用，待修复密钥兼容性问题
            // 生产环境请使用 HTTPS 保护密码传输
            String password = loginRequest.getPassword();
            logger.info("接收到的密码: [{}], 长度: {}", password, password != null ? password.length() : 0);

            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginRequest.getUsername(),
                            password
                    )
            );

            SecurityContextHolder.getContext().setAuthentication(authentication);

            String username = authentication.getName();
            String role = authentication.getAuthorities().iterator().next().getAuthority().replace("ROLE_", "");

            String token = jwtUtil.generateToken(username, role);

            logger.info("登录成功: username={}, role={}", username, role);

            LoginResponse response = new LoginResponse(token, username, role);
            return Result.success(response);
        } catch (Exception e) {
            logger.error("登录失败: username={}, error={}", loginRequest.getUsername(), e.getMessage(), e);
            return Result.error("用户名或密码错误");
        }
    }

    @GetMapping("/info")
    public Result<Map<String, Object>> getInfo() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Map<String, Object> info = new HashMap<>();
        info.put("username", authentication.getName());
        info.put("authorities", authentication.getAuthorities());
        return Result.success(info);
    }

    @PostMapping("/register")
    public Result<String> register(@RequestBody user user) {
        // TODO: 实现注册逻辑
        return Result.success("注册功能待实现");
    }

    /**
     * 测试 RSA 加密/解密
     */
    @PostMapping("/test-encrypt")
    public Result<Map<String, String>> testEncrypt(@RequestBody Map<String, String> request) {
        try {
            String original = request.get("data");
            String publicKeyStr = RsaUtil.getPublicKeyString(rsaKeyPair.getPublic());
            String privateKeyStr = RsaUtil.getPrivateKeyString(rsaKeyPair.getPrivate());

            // 加密
            String encrypted = RsaUtil.encrypt(original, publicKeyStr);

            // 解密
            String decrypted = RsaUtil.decrypt(encrypted, privateKeyStr);

            Map<String, String> result = new HashMap<>();
            result.put("original", original);
            result.put("encrypted", encrypted);
            result.put("decrypted", decrypted);
            result.put("encryptSuccess", original.equals(decrypted) ? "true" : "false");

            return Result.success(result);
        } catch (Exception e) {
            logger.error("加密测试失败", e);
            return Result.error("加密测试失败: " + e.getMessage());
        }
    }
}
