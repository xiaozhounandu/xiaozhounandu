package com.security.controller;

import com.security.common.Result;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class TestController {

    // 所有登录用户都可以访问
    @GetMapping("/hello")
    public Result<String> hello() {
        return Result.success("Hello, 你已通过认证!");
    }

    // 只有 ADMIN 角色可以访问
    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public Result<String> adminOnly() {
        return Result.success("Hello Admin, 这是管理员专属接口!");
    }

    // 只有 USER 角色可以访问
    @GetMapping("/user")
    @PreAuthorize("hasRole('USER')")
    public Result<String> userOnly() {
        return Result.success("Hello User, 这是用户专属接口!");
    }

    // ADMIN 或 USER 角色都可以访问
    @GetMapping("/dashboard")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER')")
    public Result<Map<String, String>> dashboard() {
        Map<String, String> data = new HashMap<>();
        data.put("message", "Welcome to dashboard");
        data.put("feature1", "Data visualization");
        data.put("feature2", "User management");
        return Result.success(data);
    }
}
