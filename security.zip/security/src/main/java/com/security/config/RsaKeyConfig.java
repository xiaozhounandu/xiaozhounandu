package com.security.config;

import com.security.util.RsaUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.security.KeyPair;

@Configuration
public class RsaKeyConfig {

    @Bean
    public KeyPair rsaKeyPair() throws Exception {
        return RsaUtil.generateKeyPair();
    }
}
